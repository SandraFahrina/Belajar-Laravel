@extends('layouts.app')

@section('title', 'Cobaaa')

@section('content')
    Urutan Ke - {{ $ke }}
@endsection
